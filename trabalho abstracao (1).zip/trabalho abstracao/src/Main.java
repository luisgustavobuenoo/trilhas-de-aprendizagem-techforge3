public class Main {
    public static void main(String[] args) {
        // Criando alguns alunos
        Aluno aluno1 = new Aluno("carlos almeida", 17, 70.5, 1.75);
        Aluno aluno2 = new Aluno("Maria clara", 19, 60.0, 1.68);
        Aluno aluno3 = new Aluno("vitor giese", 16, 80.3, 1.80);
        Aluno aluno4 = new Aluno("Ana maria", 21, 55.2, 1.65);

        // Exibindo informações dos alunos
        System.out.println(aluno1);
        System.out.println();
        System.out.println(aluno2);
        System.out.println();
        System.out.println(aluno3);
        System.out.println();
        System.out.println(aluno4);
}
}